module.exports = {
    posts: require('./posts'),
    comments: require('./comments')
}